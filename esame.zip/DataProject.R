library(igraph)
library(tibble)

library("RColorBrewer")

library(readr)
library(plyr)
library(dplyr)

library(ggplot2)
library(plotly)
library(collapsibleTree) 

#ottenere di dataset
student_data <- read_csv("Desktop/Università/I° ANNO/Data science/Database/student_data.csv")

#dataset con i voti dei tre trimestri
v1 <- student_data %>% select(G1, G2, G3)

# x : funzione per creare la media dei tre trimesetri
x <- function(G1,G2,G3){
  m1 <- rowMeans(v1, na.rm=FALSE, dims=1)
}
# aggiungo la colonna della media dei voti
student_data <- add_column(
        student_data,
        m1
        )

#pulizia del dataset
#rimuovere le variabili non significative (overfitting, mancanza di dati, ridondanti, idividuali)
# school e guardian non mi interessano
student_data = subset(student_data, select = -c(school, address, famsize, reason, guardian, failures, nursery, higher, Dalc))
summary(student_data)
View(student_data)

#correlazioni su caratteristiche numeriche
numeric_cols <- unlist(lapply(student_data2, is.numeric))
my_cols <- c("red","blue")
color_id <- c("true"=2, "false"=1)
pairs(student_data2[,numeric_cols], pch=19, cex=0.5, col=my_cols[color_id[student_data2$m1]])
# non ci sono dati ridondanti



# marks : dataset con le medie generali dei tre periodi
meanMarks <- student_data1 %>% select(G1, G2, G3) %>% summarise(mean(G1), mean(G2), mean(G3))
View(meanMarks)

# sistema con i voti dei tre periodi
tibble(student_data1 %>% select(G1), student_data1 %>% select(G2), student_data1 %>% select(G3))
  

#inizio grafigici

## Grafico che mostra la medie degli studenti durante l'anno scolastico 
hist(m1, probability=TRUE, ann=FALSE, col="lightblue")
title(main= "Mean of marks during the year", col.main="orange", font.main="4", xlab="Mean G1, G2, G3 (m1)", ylab="Density")
rug(m1)

plot(density(m1))

ggplot(data = student_data1)+
  geom_bar(mapping = aes(x=G1), colour="purple", fill="pink") +
  labs(title="Grade average of the first school period", 
       x="Marks of the first school period (G1)",
       y="Count")

ggplot(data = student_data)+
  geom_bar(mapping = aes(x=G2), colour="blue", fill="lightblue") +
  labs(title="Grade average of the second school period",
       x="Marks of the second school period (G2)",
       y="Count")

ggplot(data = student_data)+
  geom_bar(mapping = aes(x=G3), colour="darkgreen", fill="lightgreen") +
  labs(title="Grade average of the third school period",
       x="Marks of the third school period (G3)",
       y="Count")

## Analizo l'influenza che ha il lavoro dei genitori sui risultati scolastici dei figli
# pJobs : dataset con il lavoro di entrambi i genitori e le medie di ogni studente durante l'anno
pJobs <- student_data %>% select(Mjob, Fjob, m1)
View(pJobs)

ggplot(data = pJobs) +
  geom_bar(mapping = aes(x=Mjob), fill = cm.colors(5)) +
  labs(title="Mothers's occupation", 
       x="Mothers's jobs (Mjob)",
       y="Count")

ggplot(data = pJobs) +
  geom_count (mapping = aes(x=Mjob, y=m1), col=cm.colors(165)) +
  labs(title="Student grade average considering mother's job",
       x="Mother's job (Mjob)",
       y="Grade average (m1)")

ggplot(data = pJobs) +
  geom_bar(mapping=aes(x=Fjob), fill = heat.colors(5)) +
  labs(title="Fathers's occupation", 
     x="Fathers's jobs (Fjob)",
     y="Count")

ggplot(data = pJobs) +
  geom_count (mapping = aes(x=Fjob, y=m1), col=heat.colors(139)) +
  labs(title="Student grade average considering father's job",
       x="Father's job (Fjob)",
       y="Grade average (m1)")


## Analizzo se l'istruzione che hanno avuto i genitori di ogni studente condiziona i loro risultati scolastici
# creo tre dastaset con il livello di educazione dei genitori e la media dei voti durante l'anno
pEducation <- student_data %>% select(Medu, Fedu, m1)
View(pEducation)

ggplot(data = pEducation) +
  geom_bar(mapping = aes(x=Medu), fill = cm.colors(5)) +
  labs(title="Education level of the mother",
       x="Education level (Medu)",
       y="Count")

ggplot(data = pEducation) +
  geom_count(mapping = aes(x=Medu, y=m1), col=cm.colors(159)) +
  labs(title="Education level of the mother considering the student average",
       x="Mother education (Medu)",
       y="Grade average (m1)")

ggplot(data = pEducation) +
  geom_bar(mapping = aes(x=Fedu), fill = heat.colors(5)) +
  labs(title="Education level of the father",
       x="Education level (Fedu)",
       y="Count")

ggplot(data = pEducation) +
  geom_count(mapping = aes(x=Fedu, y=m1),  col=heat.colors(157)) +
  labs(title="Education level of the father considering the student average",
       x="Father education (Fedu)",
       y="Grade average (m1)")


## Analizzo se la situazione familiare dello studente incide sui suoi risultati scolastici
situaFam <- student_data %>% select(famrel, m1) %>% group_by(famrel) %>% summarise(mean(m1))
view(situaFam)

ggplot(data = student_data) +
  geom_boxplot (mapping = aes(x=famrel, y=m1, group=famrel), col=brewer.pal(n = 5, name = "Dark2")) +
  labs(title="Students average considering their family relationships",
       x="Family relationship (famrel)",
       y="Grade average (m1)")

relSt <- ggplot(student_data, aes(x = m1, y=famrel)) +
          geom_point(mapping = aes(colour=Pstatus, shape=Pstatus)) +
          labs(title="Students average considering family relationships and parents's situation",
               x = "Grade average(m1)",
               y = "Family relaionship (famrel)")
ggplotly(relSt)

studPar <- collapsibleTree(student_data, c("Mjob", "Fjob", "m1"))
studPar

# Analizzo le medie degli studenti con  i genitori che vivono insieme rispetto agli studenti i cui genitori vivono in case separate

situaPar <- student_data %>% select(Pstatus, m1) %>% group_by(Pstatus) %>% summarise(mean(m1))
View(situaPar)

relSituaFam <- student_data %>% select(Pstatus, famrel) %>% group_by(Pstatus) %>% summarise(mean(famrel))
View(relSituaFam)

ggplot(student_data, aes(x=Pstatus, y=m1))+
  geom_boxplot(notch=TRUE,
               fill="lightyellow",
               colour="orange",
               outlier.colour = "red") +
  theme_minimal() +
  labs(title="Average of the students considering the sentimental situation of the parents",
       x="Parents's sentimental situation (Pstatus)",
       y="Grade average (m1)")

## Analizzo la media degli studenti considerando la loro salute, le assenze e il tempo del tragitto
 
situaAbs <- student_data %>% select(absences, sex, age, m1, health) %>% group_by(sex) %>% summarise(mean(m1), mean(absences), mean(health))
View(situaAbs)
totStudAbs <- student_data %>% select(absences, sex, age, m1, health) %>% group_by(absences) %>% summarise(mean(health), mean(m1)) 
View(totStudAbs)

ggplot(student_data, aes(traveltime, absences))+
  geom_point(aes(color=sex)) +
  labs(title="Students's absences during the year considering how long does it take to get to school",
       x="Time to get to school (traveltime)",
       y="Absences (absences)")

ggplot(student_data, aes(m1, absences))+
  geom_point(aes(color=health)) +
  labs(title="Students grade average based on absences and health conditions",
       x="Grade average (m1)",
       y="Absences (absences)")

stAbs <- ggplot(student_data, aes(absences, m1)) +
      geom_point(
      data = filter(student_data, rank(m1) <= 160), size = 2.5, color="red") +
      geom_point(aes(colour = health)) +
      labs(title="Students grade average based on absences and health conditions",
           x="Absences (absences)",
           y="Grade average (m1)")
ggplotly(stAbs)

## analisi impegno studio

# supporto scolastico 

ggplot(student_data, aes(x=schoolsup, y=m1, fill=schoolsup)) + 
  geom_violin(trim=FALSE, alpha=0.7) +
  scale_fill_manual(values=c("#3333FF", "#66FF00"), guide="none") +
  geom_boxplot(width=0.1, fill = "white") +
  labs(title="Students divided by who receives educational support",
       x="Educational support (schoolsup)",
       y="Grade average (m1)")

# supporto della famiglia

student_data %>% 
  count(schoolsup, famsup) %>%  
  ggplot(mapping = aes(x = schoolsup, y = famsup)) +
  geom_tile(mapping = aes(fill = n)) +
  labs(title="Students divided into who receives family support",
       x="Educational support (schoolsup yes/no)",
       y="Family support (famsup yes/no)")

#classi a pagamento e attività extra
 
qplot(sample = m1, data = student_data, shape=paid, color = paid) +
  scale_shape_manual(values=c(1, 19)) + 
  facet_wrap(~ activities) +
  geom_hline(yintercept=9, linetype="dashed", color = "red") +
  labs(title="Students divided into those who carry out extra activities",
       x="Extra activities (activities yes/no)",
       y="Grade average (m1)")

# analizzo la media degli studenti divisa nei tre periodi dell'anno valutando le ore di studio settimanali 

study <- student_data1 %>% select(studytime, age, sex, G1, G2, G3, m1) %>% group_by(studytime) %>% summarise(mean(G1), mean(G2), mean(G3), mean(m1))
View(study)

ggplot(data = student_data) +
  geom_bar(mapping = aes(x=studytime, fill=sex), 
           position = "dodge") +
  labs(title="Hours of study divided by gender of the students",
       x="Hours of study (studytime)",
       y="Count")

ggplot(data = student_data)+
  geom_count(mapping = aes(x=studytime, y=G1, color=sex)) +
  labs(title="Grade average of the first school period based on  hours of study",
       x="Hours of study (studytime)",
       y="Marks of the first school period (G1)")

ggplot(data = student_data)+
  geom_count(mapping = aes(x=studytime, y=G2, color=sex)) +
  labs(title="Grade average of the second school period based on  hours of study",
       x="Hours of study (studytime)",
       y="Marks of the second school period (G2)")

ggplot(data = student_data)+
  geom_count(mapping = aes(x=studytime, y=G3, color=sex)) +
  labs(title="Grade average of the third school period based on  hours of study",
       x="Hours of study (studytime)",
       y="Marks of the third school period (G3)")


## Analizzo i risultati degli studenti in base al loro sesso
boyResult <- student_data %>% select(sex,age,m1) %>% filter(sex =="M")
View(boyResult)

girlResult <- student_data %>% select(sex,age,G1,G2,G3,m1) %>% filter(sex =="F")
View(girlResult)

meanBoyGirl <- student_data %>% select(sex, G1, G2, G3) %>% group_by(sex) %>% summarise(mean(G1),mean(G2),mean(G3))
View(meanBoyGirl)

g1 <- student_data1 %>% select(G1)
g2 <- student_data1 %>% select(G2)
g3 <- student_data1 %>% select(G3)
period <- c(g1 , g2 , g3)
View(period)

studAn <- collapsibleTree(student_data, c("sex", "studytime", "schoolsup", "famsup", "m1"))
studAn

marksByGender <- ddply(student_data, "sex", summarise, m1.mean=mean(m1))

resultSex <- ggplot(student_data, aes(x=m1, fill=sex)) +
              geom_density(alpha = 0.4) +
              geom_vline(data=marksByGender, aes(xintercept=m1.mean, color=sex), linetype="dashed") +
              labs(title="Grade average based con students's sex",
                   x="Grade average (m1)",
                   y="count")
ggplotly(resultSex)


## Analizzo le medie scolastiche considerando le attività nel tempo libero

# consumo di alcool nel finesettimana 
walcStud <- student_data %>% select (sex, Walc, m1, age) %>% group_by(sex) %>% summarise(mean(age), mean(m1), mean(Walc))
View(walcStud)
dalcStud <- student_data %>% select (sex, Dalc, m1, age) %>% group_by(sex) %>% summarise(mean(age), mean(m1), mean(Dalc))
View(dalcStud)

ggplot(student_data, aes(Walc, m1)) +
  geom_point(aes(color=sex)) +
  facet_wrap(~ age) +
  labs(title="Alcool consuption during the weekend and students age",
     x="Alcool consuption (Walc)",
     y="Grade average (m1)")

# ore di tempo libero
freeTime <- student_data1 %>% select(freetime, age, m1) %>% group_by(freetime) %>% summarise(mean(m1), mean(age))
View(freeTime)

ggplot(student_data, aes(freetime, m1, color=sex))+
  geom_point()+
  facet_wrap(~ sex) +
  labs(title = "Students free time",
       x = "free time during the week (freetime)",
       y  ="Grade average(m1)")

# tempo d'uscita con gli amici
goOut <- student_data1 %>% select(goout, age, m1) %>% group_by(goout) %>% summarise(mean(m1), mean(age))
View(goOut)
goOutSex <- student_data1 %>% select(sex, goout, m1) %>% group_by(sex) %>% summarise(mean(m1), mean(goout))
View(goOutSex)

freeSt <- ggplot(student_data, aes(goout, m1, color=freetime))+
      geom_point()+
      facet_wrap(~ sex) +
      labs(title = "Time students takes for go out",
         x = "Time to go out during the week (goout)",
         y  ="Grade average(m1)")
ggplotly(freeSt)

# accesso ad internet (in relazione alle ore di studio e al tempo libero)
internetAccess <- student_data %>% select(internet, age, m1) %>% group_by(internet) %>% summarise(mean(m1), mean(age))
View(internetAccess)

ggplot(student_data, aes(x=internet, y=m1))+
  geom_boxplot(notch=TRUE,
               fill = "lightblue",
               colour = "blue",
               outlier.colour = "blue") +
  labs(title="Student grade average based on their internet access",
       x="Internet access (internet)",
       y="Grade average (m1)")

ggplot(data = student_data)+
  geom_point(mapping = aes(x=studytime, y=m1, color=internet)) 

ggplot(data = student_data)+
  geom_point(mapping = aes(x=freetime, y=m1, color=internet)) 

# situazione sentimentale
studRel <- student_data1 %>% select(romantic, m1) %>% group_by(romantic) %>% summarise(mean(m1))
View (studRel)

ggplot(student_data1, aes(x=romantic, y=m1))+
  geom_boxplot(notch=TRUE,
               fill="lightpink",
               colour="red",
               outlier.colour = "red") +
  theme_minimal() +
  labs(title="Student grade average based on their sentimental situation",
       x="Sentimental situation (romantic)",
       y="Grade average (m1)")

